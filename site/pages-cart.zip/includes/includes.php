<?php
/* %%%%%%%%%%%%%%%%%%%% MENSAJES               */
	if($mensaje!=''){
		$mensajes='
			<div class="uk-container">
				<div uk-grid>
					<div class="uk-width-1-1 margin-v-20">
						<div class="uk-alert-'.$mensajeClase.'" uk-alert>
							<a class="uk-alert-close" uk-close></a>
							'.$mensaje.'
						</div>					
					</div>
				</div>
			</div>';
	}

/* %%%%%%%%%%%%%%%%%%%% RUTAS AMIGABLES        */
		$rutaInicio			=	$ruta;
		$rutaTienda 		=	$ruta.'0_0_0_tienda_wozial';
		$rutaPedido			=	$ruta.rand(1,999999999).'_revisar_orden';
		$rutaPedido2		=	$ruta.'revisar_datos_personales';
		$rutaNosotros		=	$ruta.'nosotros';
		$rutaProductos		=	$ruta.'productos';
		$rutaContacto		=	$ruta.'contacto';
		$rutaArticulos		=	$ruta.'0_0_0_articulos';
		$rutaEspecificaciones		=	$ruta.'especificaciones';

/* %%%%%%%%%%%%%%%%%%%% MENU                   */
	$menu='
		<li class="'.$nav1.'"><a class="" href="'.$rutaInicio.'"><b>INICIO</b></a></li>
		<li class="'.$nav2.'"><a class="" href="'.$rutaNosotros.'"><b>NOSOTROS</b></a></li>
		<li class="'.$nav3.'"><a class="" href="'.$rutaProductos.'"><b>PRODUCTOS</b></a></li>
		<li class="'.$nav4.'"><a class="" href="'.$rutaContacto.'"><b>CONTACTO</b></a></li>
		<li class="'.$nav5.'"><a class="" href="'.$rutaTienda.'"><b>ARTICULOS</b></a></li>
		<li class="'.$nav6.'"><a class="" href="'.$rutaEspecificaciones.'"><b>Especificaciones</b></a></li>

		';

	$menuMovil='
		<li><a class=" '.$nav1.'" href="'.$rutaInicio.'">INICIO</a></li>
		<li><a class=" '.$nav2.'" href="'.$rutaNosotros.'">NOSOTROS</a></li>
		<li><a class=" '.$nav3.'" href="'.$rutaProductos.'">PRODUCTOS</a></li>
		<li><a class=" '.$nav4.'" href="'.$rutaContacto.'">CONTACTO</a></li>

		';

/* %%%%%%%%%%%%%%%%%%%% HEADER                 */
$header='
<div class="uk-offcanvas-content uk-position-relative">

	<header>
		<div class="uk-margin-remove" style="padding-right: 0px;">
			<div uk-grid >

				<!-- Botón menú móviles -->
				<div class="uk-width-1-2 uk-hidden@m">
					<a href="#menu-movil" uk-toggle class="uk-button uk-button-default color-primary"><i class="fa fa-bars" aria-hidden="true"></i> &nbsp; MENÚ</a>
				</div>
			

				<!-- Menú escritorio -->
				<div class="uk-width-expand@m uk-visible@m header-container ">

					<nav class="uk-width-1-1 uk-navbar-container navbar-container-nav uk-box-shadow-large" style="height: 60px;" uk-navbar="mode: click">
						<div class="uk-width-auto uk-navbar-left">
				
							<ul class="uk-width-auto uk-navbar-nav uk-nav-default uk-nav-parent-icon" style="height: 100%;" uk-nav >
								<li class="navbar-bikes">
									<a class="" style=" height: auto; width: 150px" href="#" id="bikes-nav">BIKES &nbsp; <i id="icon-bikes" class="fas fa-chevron-up"></i></a>

									<div class="navbar-bikes-opt uk-navbar-dropdown">
										<ul class="uk-nav uk-navbar-dropdown-nav">
										';

										$CONSULTA = $CONEXION -> query("SELECT * FROM productoscat WHERE parent = 9");
									    while ($rowCONSULTA = $CONSULTA -> fetch_assoc()) {
										$titulo = $rowCONSULTA['txt'];
										$id = $rowCONSULTA['id'];


										$header.='
											<li><a  href="'.$id.'_0_0_tienda_wozial">'.$titulo.'</a></li>
										';
									}

										$header.='	
										</ul>
										
									</div>
								</li>
								<li class="navbar-menu">
									<a class="uk-link-reset uk-margin-remove uk-padding-remove" style=" height: auto" href="#">
										<div  class="uk-grid ">
										<div class="uk-width-1-1 uk-flex uk-flex-center" id="menu-nav">MENU</div>
										<div class="uk-width-1-1 uk-flex uk-flex-center"><i id="icon-menu" class="fas fa-angle-down"></i></div>
									</div>
									</a>
									<div class="uk-navbar-dropdown uk-margin-remove navbar-menu-opt">
										<ul class="uk-nav uk-navbar-dropdown-nav">
											<li><a href="'.$rutaInicio.'">HOME</a></li>
											<ul class="uk-nav-default uk-nav-parent-icon" uk-nav>
												<li class="uk-parent ">
													<a href="#">TIENDA</a>
													<ul class="uk-nav-default uk-nav-parent-icon navbar-menu-subopt" uk-nav>';

													$CONSULTA = $CONEXION -> query("SELECT * FROM productoscat WHERE parent = 0");
													    while ($rowCONSULTA = $CONSULTA -> fetch_assoc()) {
														$titulo = $rowCONSULTA['txt'];
														$id = $rowCONSULTA['id'];

														$header.='	

														<li class="uk-parent"><a href="#">'.$titulo.'</a>
															<ul class="uk-nav-sub navbar-menu-bikes-cont">

															';
															$sqlsub = "SELECT * FROM productoscat WHERE parent = $id";
															$CONSULTAsub = $CONEXION -> query($sqlsub);
															    while ($rowCONSULTAsub = $CONSULTAsub -> fetch_assoc()) {
																$titulosub = $rowCONSULTAsub['txt'];
																$idsub = $rowCONSULTAsub['id'];
																$header.='	
																<li><a href="'.$idsub.'_0_0_tienda_wozial">'.$titulosub.'</a></li>';
																}
																$header.='

															</ul>
														</li>
														';
														}

													$header.='	
													</ul>
												</li>
											</ul>
											<li><a href="'.$rutaNosotros.'">SUCURSALES</a></li>
											<li><a href="'.$rutaContacto.'">CONTACTO</a></li>
										</ul>
									</div>
								</li>
								<li class="navbar-logo">
									<a href="'.$rutaInicio.'">
										<img style="width: 8em; height: 2em;" src="./img/design/logoBike.png" alt="logo">
									</a>
								</li>
							</ul>
						</div>

						<div class="uk-flex uk-flex-right uk-flex-middle navbar-redes uk-width-expand@l">
							'.$loginButton.'
							<a href='.$socialWhats.' target="_blank" style="background-color: white;" class="uk-icon-button uk-margin-small-right"><img style="width: 45%; height: 45%" src="./img/design/logo-whats.png" alt=""></a>
							<a href='.$socialInst.' target="_blank" style="background-color: white;" class="uk-icon-button  uk-margin-small-right"><img style="width: 45%; height: 45%" src="./img/design/logo-insta.png" alt=""></a>
							<a href='.$socialFace.' target="_blank" style="background-color: white;" class="uk-icon-button uk-margin-small-right"><i style="width: 45%; height: 45%; color: black" class="fab fa-facebook-f"></i></a>
							<a href='.$socialYou.' target="_blank" style="background-color: white;" class="uk-icon-button  uk-margin-small-right"><img style="width: 45%; height: 45%" src="./img/design/logo-youtube.png" alt=""></a>
						</div>
					</nav>
				</div>
		</header>
			
	<!-- Menú móviles -->
	<div id="menu-movil" uk-offcanvas="mode: push;overlay: true">
		<div class="uk-offcanvas-bar uk-flex uk-flex-column">
			<button class="uk-offcanvas-close" type="button" uk-close></button>
			<ul class="uk-nav uk-nav-primary uk-nav-parent-icon uk-nav-center uk-margin-auto-vertical" uk-nav>
				'.$menuMovil.'
			</ul>
		</div>
	</div>
</div>';


		

/* %%%%%%%%%%%%%%%%%%%% FOOTER                 */
	$whatsIconClass=(isset($_SESSION['whatsappHiden']))?'':'uk-hidden';
	$stickerClass=($carroTotalProds==0 OR $identificador==500 OR $identificador==501 OR $identificador==502)?'uk-hidden':'';
	$footer = '
	<footer>
		<div class="bg-footer" style="z-index: 0;">
			<div class="uk-container-expand uk-position-relative">


				<div class="uk-width-expand@m" style="position: relative; z-index: 4; top: 2em; left: 4%; width: 94%">

					<nav class="uk-navbar-container uk-width-1-1" uk-navbar style="background-color: transparent; position: relative; z-index: 980; height: 55px;">
						<div style="background-color: transparent" class="uk-width-auto@m uk-navbar-left">
				
							<ul class="uk-navbar-nav" style="height: 55px;">
								<li style="margin-right: .2em;background-color: black; padding: 10px;">
									<a style="color: white; font-size: .90em; letter-spacing: 4px; width: 8.5em;" href="#">BIKES  &nbsp; <i id="icon-bikes" class="fas fa-chevron-up"></i></a>
									<div class="uk-navbar-dropdown" uk-dropdown="pos: top-right">
										<ul class="uk-nav uk-navbar-dropdown-nav">
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">ROAD</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">MOUNTAIN</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">ACTIVE</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">ELECTRIC</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">KIDS</a></li>
										</ul>
									</div>
								</li>
								<li style="margin-right: .2em;background-color: black; padding: 10px;">
									<a style="margin-right: .2em; color: white; padding:0px;padding-top: .5em; font-size: .6em;" href="#">MENU <i id="icon-menu" class="fas fa-angle-down"></i></a>
									<div class="uk-navbar-dropdown navbar-menu-foo" uk-dropdown="pos: top-right">
										<ul class="uk-nav uk-navbar-dropdown-nav">
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">HOME</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">TIENDA</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">SUCURSALES</a></li>
											<li><a style="color: black; font-size: 2em; font-weight: 800; margin: 0; padding: 0;" href="#">CONTACTO</a></li>
										</ul>
									</div>
								</li>
								<li style="margin-right: .2em;background-color: black; padding: 10px;">
									<a href="#">
										<img style="width: 7em; height: 2em;" src="./img/design/logoBike.png" alt="logo">
									</a>
								</li>
							</ul>
						</div>

						<div style="height:55px; background-color: black;" class="uk-width-expand uk-flex uk-flex-right uk-flex-middle">
							<a style="padding-left: 1em; background-color: black; width: 4em" href="" class="uk-icon-button uk-margin-small-right"><p style="font-size: 12px; margin-bottom: 0; color: white; background-color: black">UBICACIONES</p></a>
							<a style="background-color: black; width: 9em" href="" class="uk-icon-button  uk-margin-small-right"><p style="font-size: 12px; margin-bottom: 0; color: white; background-color: black">AVISO DE PRIVACIDAD</p></a>
							<a style="background-color: black; width: 11em" href="" class="uk-icon-button uk-margin-small-right"><p style="font-size: 12px; margin-bottom: 0; color: white; background-color: black">POLITICAS Y CONDICIONES</p></a>
							<a style="background-color: black; width: 5em" href="" class="uk-icon-button  uk-margin-small-right"><p style="font-size: 12px; margin-bottom: 0; color: white; background-color: black">POLITICAS</p></a>
							<a href='.$socialWhats.' target="_blank" style="background-color: black;" class="uk-icon-button uk-margin-small-right"><img style="width: 45%; height: 45%" src="./img/design/what.png" alt=""></a>
							<a href='.$socialInst.' target="_blank" style="background-color: black;" class="uk-icon-button  uk-margin-small-right"><img style="width: 45%; height: 45%" src="./img/design/insta.png" alt=""></a>
							<a href='.$socialFace.' target="_blank" style="background-color: black;" class="uk-icon-button uk-margin-small-right"><i style="width: 45%; height: 45%; color: white" class="fab fa-facebook-f"></i></a>
							<a href='.$socialYou.' target="_blank" style="background-color: black;" class="uk-icon-button  uk-margin-small-right"><img style="width: 45%; height: 45%" src="./img/design/you.png" alt=""></a>	
						</div>
						
						</div>
					</nav>
				</div>	


				<div class="uk-width-1-1 uk-text-center">
					<div class="padding-v-50" style="margin: 0em; padding: 2.5em 0em; background-color: white; color: black">
						<a href="https://wozial.com/" target="_blank" class="color-negro"><b>Wozial Marketing Lovers</b></a>
					</div>
				</div>
			</div>
		</div>
	</footer>






		<div id="cotizacion-fixed" class="uk-position-top uk-height-viewport '.$stickerClass.'">
			<div>
				<a class="" href="'.$rutaPedido.'"><img src="img/design/checkout.png" id="cotizacion-fixed-img"></a>
			</div>

		</div>

		'.$loginModal.'

		<!-- <div id="whatsapp-plugin" class="uk-hidden">
			<div id="whats-head" class="uk-position-relative">
				<div uk-grid class="uk-grid-small uk-grid-match">
					<div>
						<div class="uk-flex uk-flex-center uk-flex-middle">
							<img class="uk-border-circle padding-10" src="img/design/logo-og.jpg" style="width:70px;">
						</div>
					</div>
					<div>
						<div class="uk-flex uk-flex-center uk-flex-middle color-blanco">
							<div>
								<span class="text-sm">'.$Brand.'</span><br>
								<span class="text-6 uk-text-light">Atención en línea vía chat</span>
							</div>
						</div>
					</div>
				</div>
				<div class="uk-position-right color-blanco text-sm">
					<span class="pointer padding-10" id="whats-close">x</spam>
				</div>
			</div>
			<div id="whats-body-1" class="uk-flex uk-flex-middle">
				<div class="bg-white uk-border-rounded padding-h-10" style="margin-left:20px;">
					<img src="img/design/loading.gif" style="height:40px;">
				</div>
			</div>
			<div id="whats-body-2" class="uk-hidden">
				<span class="uk-text-bold uk-text-muted">'.$Brand.'</span><br>
				Hola 👋<br>
				¿Cómo puedo ayudarte?
			</div>
			<div id="whats-footer" class="uk-flex uk-flex-center uk-flex-middle">
				<a href="'.$socialWhats.'" target="_blank" class="uk-button uk-button-small" id="button-whats"><i class="fab fa-whatsapp fa-lg"></i> <span style="font-weight:400;">Comenzar chat</span></a>
			</div>
		</div>
		<div id="whats-show" class="'.$whatsIconClass.' pointer uk-border-circle color-white uk-box-shadow-large" style="background-color: rgb(9, 94, 84);">
			<i class="fab fa-3x fa-whatsapp"></i>
		</div> --> 
	</div>

	<div id="spinnermodal" class="uk-modal-full" uk-modal>
		<div class="uk-modal-dialog uk-flex uk-flex-center uk-flex-middle uk-height-viewport">
			<div>
				<div class="claro" uk-spinner="ratio: 5">
				</div>
			</div>
		</div>
   	</div>';

/* %%%%%%%%%%%%%%%%%%%% HEAD GENERAL                */
	$headGNRL='
		<html lang="'.$languaje.'">
		<head prefix="og: http://ogp.me/ns# fb: http://ogp.me/ns/fb# website: http://ogp.me/ns/website#">

			<meta charset="utf-8">
			<title>'.$title.'</title>
			<meta name="description" content="'.$description.'" />
			<meta property="fb:app_id" content="'.$appID.'" />
			<link rel="image_src" href="'.$ruta.$logoOg.'" />

			<meta property="og:type" content="website" />
			<meta property="og:title" content="'.$title.'" />
			<meta property="og:description" content="'.$description.'" />
			<meta property="og:url" content="'.$rutaEstaPagina.'" />
			<meta property="og:image" content="'.$ruta.$logoOg.'" />

			<meta itemprop="name" content="'.$title.'" />
			<meta itemprop="description" content="'.$description.'" />
			<meta itemprop="url" content="'.$rutaEstaPagina.'" />
			<meta itemprop="thumbnailUrl" content="'.$ruta.$logoOg.'" />
			<meta itemprop="image" content="'.$ruta.$logoOg.'" />

			<meta name="twitter:title" content="'.$title.'" />
			<meta name="twitter:description" content="'.$description.'" />
			<meta name="twitter:url" content="'.$rutaEstaPagina.'" />
			<meta name="twitter:image" content="'.$ruta.$logoOg.'" />
			<meta name="twitter:card" content="summary" />

			<meta name="viewport"       content="width=device-width, initial-scale=1">

			<link rel="icon"            href="'.$ruta.'img/design/favicon.ico" type="image/x-icon">
			<link rel="shortcut icon"   href="img/design/favicon.ico" type="image/x-icon">
			<link rel="stylesheet"      href="https://cdn.jsdelivr.net/npm/uikit@'.$uikitVersion.'/dist/css/uikit.min.css" />
			<link rel="stylesheet/less" href="css/general.less" >
			<link rel="stylesheet"      href="https://fonts.googleapis.com/css?family=Lato:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i">
			<link rel="preconnect" href="https://fonts.gstatic.com">
            <link href="https://fonts.googleapis.com/css2?family=Asap:wght@400;700&display=swap" rel="stylesheet">
			<link rel="preconnect" href="https://fonts.gstatic.com">
            <link href="https://fonts.googleapis.com/css2?family=Nanum+Gothic:wght@400;700;800&display=swap" rel="stylesheet">

			<!-- jQuery is required -->
			<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

			<!-- UIkit JS -->
			<script src="https://cdn.jsdelivr.net/npm/uikit@'.$uikitVersion.'/dist/js/uikit.min.js"></script>
			<script src="https://cdn.jsdelivr.net/npm/uikit@'.$uikitVersion.'/dist/js/uikit-icons.min.js"></script>

			<!-- Font Awesome -->
			<script src="https://kit.fontawesome.com/910783a909.js" crossorigin="anonymous"></script>

			<!-- Less -->
			<script src="//cdnjs.cloudflare.com/ajax/libs/less.js/3.9.0/less.min.js" ></script>
		</head>';

/* %%%%%%%%%%%%%%%%%%%% SCRIPTS                */
	$scriptGNRL='
		<script src="js/general.js"></script>

	<!--	<script src="//code.jivosite.com/widget.js" data-jv-id="R4ZWEOn0XH" async></script> -->
		
		';

	// Script login Facebook
	$scriptGNRL.=(!isset($_SESSION['uid']) AND $dominio != 'localhost' AND isset($facebookLogin))?'
		<script>
			// Esta es la llamada a facebook FB.getLoginStatus()
			function statusChangeCallback(response) {
				if (response.status === "connected") {
					procesarLogin();
				} else {
					console.log("No se pudo identificar");
				}
			}

			// Verificar el estatus del login
			function checkLoginState() {
				FB.getLoginStatus(function(response) {
					statusChangeCallback(response);
				});
			}

			// Definir características de nuestra app
			window.fbAsyncInit = function() {
				FB.init({
					appId      : "'.$appID.'",
					xfbml      : true,
					version    : "v'.$appVersion.'"
				});
				FB.AppEvents.logPageView();
			};

			// Ejecutar el script
			(function(d, s, id){
				var js, fjs = d.getElementsByTagName(s)[0];
				if (d.getElementById(id)) {return;}
				js = d.createElement(s); js.id = id;
				js.src = "//connect.facebook.net/es_LA/sdk.js";
				fjs.parentNode.insertBefore(js, fjs);
			}(document, \'script\', \'facebook-jssdk\'));
			
			// Procesar Login
			function procesarLogin() {
				FB.api(\'/me?fields=id,name,email\', function(response) {
					console.log(response);
					$.ajax({
						method: "POST",
						url: "includes/acciones.php",
						data: { 
							facebooklogin: 1,
							nombre: response.name,
							email: response.email,
							id: response.id
						}
					})
					.done(function( response ) {
						console.log( response );
						datos = JSON.parse( response );
						UIkit.notification.closeAll();
						UIkit.notification(datos.msj);
						if(datos.estatus==0){
							location.reload();
						}
					});
				});
			}
		</script>

		':'';


// Reportar actividad
	$scriptGNRL.=(!isset($_SESSION['uid']))?'':'
		<script>
			var w;
			function startWorker() {
			  if(typeof(Worker) !== "undefined") {
			    if(typeof(w) == "undefined") {
			      w = new Worker("js/activityClientFront.js");
			    }
			    w.onmessage = function(event) {
					//console.log(event.data);
			    };
			  } else {
			    document.getElementById("result").innerHTML = "Por favor, utiliza un navegador moderno";
			  }
			}
			startWorker();
		</script>
		';

/* %%%%%%%%%%%%%%%%%%%% BUSQUEDA               */
	$scriptGNRL.='
		<script>
			$(document).ready(function(){
				$(".search").keyup(function(e){
					if(e.which==13){
						var consulta=$(this).val();
						var l = consulta.length;
						if(l>2){
							window.location = ("'.$ruta.'"+consulta+"_gdl");
						}else{
							UIkit.notification.closeAll();
							UIkit.notification("<div class=\'bg-danger color-blanco\'>Se requiren al menos 3 caracteres</div>");
						}
					}
				});
				$(".search-button").click(function(){
					var consulta=$(".search-bar-input").val();
					var l = consulta.length;
					if(l>2){
						window.location = ("'.$ruta.'"+consulta+"_gdl");
					}else{
						UIkit.notification.closeAll();
						UIkit.notification("<div class=\'bg-danger color-blanco\'>Se requiren al menos 3 caracteres</div>");
					}
				});
			});
		</script>';

/* %%%%%%%%%%%%%%%%%%%% WHATSAPP PLUGIN               
	$scriptGNRL.=(isset($_SESSION['whatsappHiden']))?'':'
		<script>
			setTimeout(function(){
				$("#whatsapp-plugin").addClass("uk-animation-slide-bottom-small");
				$("#whatsapp-plugin").removeClass("uk-hidden");
			},1000);
			setTimeout(function(){
				$("#whats-body-1").addClass("uk-hidden");
				$("#whats-body-2").removeClass("uk-hidden");
			},6000);
		</script>
			'; */
