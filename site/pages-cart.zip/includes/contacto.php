<!DOCTYPE html>
<?=$headGNRL?>
<body>
  
<?=$header?>

<div class='uk-container uk-container-xpand'>
    <div class="uk-grid-small uk-child-width-1-3" uk-grid> 
        <div class="uk-text-primary uk-height-medium"></div>
        Hola mundo
    </div>
</div>

<?=$footer?>

<?=$scriptGNRL?>

</body>
</html>