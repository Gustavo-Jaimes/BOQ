#[jQuery Upload File](http://hayageek.com/docs/jquery-upload-file.php)

##Overview
jQuery Upload File plugin provides Multiple file Uploads with progress bar.Works with any server-side platform (Google App Engine, PHP, Python, Ruby on Rails, Java, etc.) that supports standard HTML form file uploads.

---

#Demo
http://hayageek.com/docs/jquery-upload-file.php

---
#Documentation
http://hayageek.com/docs/jquery-upload-file.php#doc

