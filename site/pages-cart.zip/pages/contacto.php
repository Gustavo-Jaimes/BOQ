<!DOCTYPE html>
<?=$headGNRL?>
<body>
  
<?=$header?>

<div class="uk-text-center" uk-grid style="height: 83vh">
    <div class="uk-width-1-3@m">
        <div class="uk-background-cover uk-light" data-src="./img/design/banner-contacto.png" uk-img style="background-position:left;height:100%;">
        </div>
    </div>
    <div class="uk-width-expand@m padding-v-50 uk-flex uk-flex-middle container-form" >
            <div class="uk-margin-auto-vertical">
                <h1 class="uk-align-left@m">te ayudamos...</h1>
                    <div class="uk-width-1-1@m">
                       <input class="form-contac form-contac-movil text-xl-contac" id="footernombre" name="footernombre" type="text" placeholder="tu nombre:" autocomplete="off">
                    </div>
                    <div class="uk-width-1-1@m">
                      <input class="form-contac form-contac-movil text-xl-contac" id="footeremail" name="footeremail" type="email" placeholder="correo:" autocomplete="off">
                    </div>
                    <div class="uk-width-1-1@m">
                      <input class="form-contac form-contac-movil text-xl-contac" id="footertelefono" name="footertelefono" type="text" placeholder="whatsapp:" autocomplete="off">
                    </div>
                    <div class="uk-width-1-1@m">
                      <input class="form-contac form-contac-movil text-xl-contac" id="footercomentarios" name="footercomentarios" type="text" placeholder="mensaje:" autocomplete="off">
                    </div>
                    <div class="uk-width-1-1@m uk-text-left" style="margin-top: 10px">
                      <button class="uk-button button-cotiza-dark uk-padding-remove contac-enviar" id="footersend">Enviar ></button>
                    </div>         
            </div>
    </div>
</div>
<?=$footer?>

<?=$scriptGNRL?>

</body>
</html>