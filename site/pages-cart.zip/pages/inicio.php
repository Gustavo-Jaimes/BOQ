<!DOCTYPE html>
<?=$headGNRL?>
<body>

<?=$header?>
<div>
	<//?=//carousel('carousel')?>
    
</div>
<!-- //banner principal -->
<div class="uk-text-center uk-grid-match"  uk-grid>
    <div class="uk-width-2-3@m">
        <div class="uk-card" style="margin-right: 8px">
         <div class="uk-position-relative uk-visible-toggle uk-dark" tabindex="-1" uk-slideshow>
         <ul class="uk-slideshow-items slider-container" style="height: 650px">
         <?php 
            $CONSULTA6 = $CONEXION -> query("SELECT * FROM carousel ORDER BY orden");
            while($rowCONSULTA6 = $CONSULTA6 -> fetch_assoc()){
                $pic = './img/contenido/carousel/'.$rowCONSULTA6['imagen'];
              ?>
           
                <li>
                    <img class="banner-img" src="<?=$pic?>" alt="" uk-cover>
                </li>
                <?php } ?>
            </ul>
            <div class="uk-position-bottom-right slider-nav-flechas">
               <a class=" uk-position-small " href="#" style="color: red;" uk-slidenav-previous uk-slideshow-item="previous"></a>
               <a class=" uk-position-small" href="#" style="color: red;" uk-slidenav-next uk-slideshow-item="next"></a>
            </div>
        </div>

      </div>
    </div>
    <div class="uk-width-1-3@m uk-flex uk-flex-middle banner-letrero-container">
        <div class="banner-letrero-sub">
                 <h1 class="banner-letrero-h1"><b>TRAIL</b></h1>
                 <h3 class="banner-letrero-h3">DOMINA LA MONTAÑA</h3>
                 <p class="banner-letrero-p">Lorem ipsum es simplemente el texto de relleno de las imprentas y archivos de texto. Lorem Ipsum ha sido el texto de relleno estandar de las industrias desde el año 1500. elit.</p>
                <h5 class="banner-letrero-h5">Mas > </h5>
        </div>
    </div>
</div>

    <!-- banner favoritos -->
<div class="uk-container" style="height: 17em; padding-top: 3em;">   
<div class="uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slideshow>

    <ul class="uk-slideshow-items" style="padding: 3em 0; ">
       <?php 
        $defaultPic ="./img/design/bici.png";
        $CONSULTA4 = $CONEXION -> query("SELECT * FROM productos WHERE favoritos= 1");
        while($rowCONSULTA4 = $CONSULTA4 -> fetch_assoc()){
         $id = $rowCONSULTA4['id'];
         $tituloPro = $rowCONSULTA4['titulo'];
        
         $pic2 = $defaultPic;
        $CONSULTA5 = $CONEXION -> query("SELECT * FROM productospic WHERE producto= $id LIMIT 1");
        while($rowCONSULTA5 = $CONSULTA5 -> fetch_assoc()){
        $pic2 ='./img/contenido/productos/'.$rowCONSULTA5['id'].'.png';
        }
        if (file_exists($pic2)) {
            $pic2 = $pic2;
        }
        ?>

        <li>
            <div class="uk-grid uk-width-1-1" uk-grid >
                <div class="uk-width-1-2">
                    <h1 class="favoritos-h1" style="color: red; text-align: left; font-size: 3em; letter-spacing: 5px; margin: 0;"><b>FAVORITOS</b></h1>
                    <h2 class="favoritos-h2" style="color: black; font-weight: 900; margin: 0;"><?=$tituloPro?></h2>
                    <p class="favoritos-p" >hola ipsum dolor sit amet consectetur adipisicing elit. Voluptatum dolores natus, commodi aut earum odit ut omnis cumque eum cupiditate nesciunt eveniet, nam, a magni. Porro magnam molestias optio deserunt?</p>
                    <h5 class="banner-letrero-ver" style="color: black; background-color: transparent; padding: 0; width: 3.5em; text-align: right; margin: 0px; padding-top: 1em;">VER > </h5>
                </div>
                
                <div class="uk-width-1-2 uk-flex uk-flex-center uk-flex-middle">
                    <div class=" favoritos-banner ">
                        <img style="max-height:13em"  src="<?=$pic2?>" alt="">
                        <?php } ?>
                    </div>
                </div>
            </div>
        </li>
        
    </ul>

    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
    <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>

</div> 
</div>

<!-- Slider de categorias -->

<div class="uk-position-relative uk-visible-toggle uk-light" style="margin-left:.1em;" tabindex="-1" uk-slider>
  <ul class="uk-slider-items uk-child-width-1-2 uk-child-width-1-3@s uk-child-width-1-5@m">
    <?php
        $CONSULTA = $CONEXION -> query("SELECT * FROM productoscat WHERE parent = 9");
        while ($rowCONSULTA = $CONSULTA -> fetch_assoc()) {
            $titulo = $rowCONSULTA['txt'];
            $pic = './img/contenido/productos/'.$rowCONSULTA['imagen'];
            $id = $rowCONSULTA['id'];
    ?>
        <li style="margin-right: 0.2em;">
            <div class="uk-width-1-1 uk-inline-clip uk-transition-toggle" tabindex="0">
                <div class="uk-width-1-1 uk-background-cover uk-panel uk-flex uk-flex-center uk-flex-middle uk-height-large" 
                style="background-image: url(<?=$pic?>);background-position:top">
                </div>
                <!--img src="<?=$pic?>" alt=""-->
                <div class="uk-transition-slide-bottom uk-flex uk-flex-middle uk-position-bottom uk-overlay uk-overlay-default" style="background-color: rgba(237, 79, 28, 0.8); height: 150px">
                    <a href="<?=$id?>_0_0_tienda_wozial"><p  class="uk-h4 uk-margin-remove" style="color: white; font-size: 2em; font-weight:700"><?=$titulo?></p></a>
                </div>
            </div>
        </li>
        <?php }?>
    </ul>   

    <a class="uk-position-center-left uk-position-small uk-hidden-hover" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
    <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>

</div>


  <!-- Seccion de marcas -->
  <div class="uk-text-center uk-grid-small" uk-grid>
    <div class="uk-width-expand@m">
        <div class="">
            <h1 class="marcas-h1">NUESTRAS MARCAS</h1>
        </div>
    </div>
</div>

<div class="uk-text-center marcas-logo-container" uk-grid>
    <div class="uk-width-1-1@m uk-position-relative uk-visible-toggle uk-light" tabindex="-1" uk-slider>
        <ul class="uk-slider-items uk-child-width-1-4@m uk-grid ">
            <?php 
            $CONSULTA3 = $CONEXION -> query("SELECT * FROM empresas LIMIT 4");
            while($rowCONSULTA1 = $CONSULTA3 -> fetch_assoc()){
            $pic1 ='./img/contenido/empresas/'.$rowCONSULTA1['imagen'];
           ?>
            
                <li>
                    <img src="<?=$pic1?>" alt="">
                </li>
           <?php } ?>
        </ul>
            <a class="uk-position-center-left uk-position-small uk-hidden-hover" style="font-size: 1em" href="#" uk-slidenav-previous uk-slider-item="previous"></a>
            <a class="uk-position-center-right uk-position-small uk-hidden-hover" href="#" uk-slidenav-next uk-slider-item="next"></a>
         
    </div>

</div>

<!-- Seccion Demo Ride -->
<div class=" uk-text-center demo-ride-container uk-grid-small" uk-grid>
    <div  class="uk-width-1-2 " >
        <div class="demo-ride-subcontainer">
            <h1 class="demo-ride-h1">DEMO RIDE</h1>
            <p class="demo-ride-p">Lorem ipsum dolor sit amet consectetur adipisicing elit. Officia labore repudiandae iusto provident eius ex vitae 
               numquam quis, est laboriosam, porro laudantium molestiae voluptatem ad libero. Minima veniam eveniet iusto?</p>
            <h5 class="banner-letrero-h5">Mas > </h5>
        </div>
    </div>
    <div class="uk-width-1-2">           <!--Se coloca el contenido de aqui en widgets. Se manda llamar la funcion item    -->
        <div uk-slideshow>                <!--es la que imprime el contenido que tiene widgets en esta seccion.    -->
                                      <!--La primera consulta se hace para consultar el numero de productos y producir la paginacion, que solo admita 4 productos por paguina.   -->
            <ul class="uk-slideshow-items" style="height: 42em;"><!--    -->
                <?php
                    $CONSULTA1 = $CONEXION -> query("SELECT * FROM productos"); //consultamos la tabla productos
                    $numrows = $CONSULTA1 ->num_rows;       //en la variable numrows metemos la consulta que se hace
                    $numPag = $numrows/4;             //en la variable numPag metemos el contenido de numrows y lo dividimos en 4 se son 4 productos por pagina
                    $resto = $numrows%4;              // en la variable resto metemos el residuo de numrows, serian numeros que no quepan en 4 como 1 2 3
                    if($resto!=0){                    //si el residuo resto es diferente de cero
                       $numPag= $numPag+1;            // entonces numpag vamos agregar estos item en una nueva pagina. En esta pagina se vera solo 1 2 3 productos.
                    }                                 // esto hace que mi pantalla produzca 4 productos por pagina
                    $ini =0;                           // ini de declara para que empiece en la posicion 0 
                    $recorido =4;                      // esta variable va a recorrer 4 posiciones mas a partir de 1, que seria mis 4 productos
                    for ($i=1; $i <= $numPag; $i++) {  // este for hace mi paginacion. si mi variable 1 es menor o igual al numPag sie esto se cumple entonces imprime mi consulta y mi codigo html
                        
                    
                ?>
                <li>                                      
                    <div class="uk-child-width-1-2 uk-text-center uk-margin-remove uk-grid-small" uk-grid><!--  aqui arma mi estructura de 1/2 de ancho que le di donde imprimira mi consulta en este espacio.  -->
                        <?php
                        $CONSULTA1 = $CONEXION -> query("SELECT * FROM productos LIMIT $ini,$recorido");  //Se realiza la consulta y se limita a estas dos variables para que solo muestre 4 productos por pagina
                        
                        while($row_CONSULTA1 = $CONSULTA1 -> fetch_assoc()){  //El while lo usamos cuando queremos consular mas de 1 producto
                        
                        echo item($row_CONSULTA1['id']);         //imprime el contenido de widgets. Solo le pasamos un parametro asi como esta definida la funcion en widgets.
                        }
                        ?>       
                    </div>
                </li>
                <?php  $ini= $ini+4; }?>  <!-- Cerramos nuestro while y nuestro php y a la variable ini le sumamos las 4 pocisiones que tubo esta consulta para que en caso de que se cumpla la condicion, imprima las siguientes 4.                  -->
            </ul>
            <ul class="uk-slideshow-nav uk-dotnav uk-flex-center uk-margin"></ul> <!--  Los puntitos de abajo que marcan la paginacion -->
        </div>
    </div>
</div>
 <!-- La seccion que se muestran los productos, tienen que redirigir a la seccion de especificaciones. Para redireccionarlos lo hacemos en widgest -->

<?=$footer?>

<?=$scriptGNRL?>

</body>
</html>