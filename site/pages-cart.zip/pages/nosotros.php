<!DOCTYPE html>
<?=$headGNRL?>
<body>
  
<?=$header?>


<div uk-grid style="height: 83vh">
    <div class="uk-width-1-3@m">
		<div>
		<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d14932.699572668078!2d-103.42923681200462!3d20.66246250555956!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8428afb0babdb043%3A0xd1a1e8db72bdeb19!2sVIDAL%20Life%20Plaza!5e0!3m2!1ses-419!2smx!4v1620840974943!5m2!1ses-419!2smx"  style="border:0; width: 100%; height: 83vh" allowfullscreen="" loading="lazy"></iframe>
		</div>
	</div>
    <div class="uk-width-2-3" style="background-color: #e0e0e0; padding-left: 4em">
	    <div class="uk-flex uk-flex-center">
	      <img style="max-width: 14em; margin-top: 8em" src="./img/design/cannon.png" alt="cannon">
		</div>
		<h1 style="font-size: 4.5em; font-weight:800; margin: 0; letter-spacing: 2px;">Sucursales</h1>
		<h3 style="font-size: 2em; font-weight:800; margin:0">Guadalupe</h3>
		<p style="font-size: .7em; padding-bottom: 4em">Avenida Guadalupe 4599 <br> Plaza vidal local 8 <br> Tel. <br>Whatsapp <br>correo@.com</p>
	</div>
</div>


<?=$footer?>

<?=$scriptGNRL?>

</body>
</html>